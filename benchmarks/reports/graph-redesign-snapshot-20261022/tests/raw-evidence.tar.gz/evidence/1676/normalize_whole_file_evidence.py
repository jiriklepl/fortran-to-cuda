"""Derive selected nodes from a sealed inventory; retain actual whole-file argv."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path('/home/jirka/research/fortran-abomination')


def bound(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': sha256(path.read_bytes()).hexdigest()}


def checked(path, expected):
    item = bound(path)
    assert item['sha256'] == expected, item
    return json.loads(Path(path).read_text())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--summary', type=Path, required=True)
    parser.add_argument('--summary-sha256', required=True)
    parser.add_argument('--inventory', type=Path, required=True)
    parser.add_argument('--inventory-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), 'Fresh normalized metadata output required'
    raw = checked(args.summary, args.summary_sha256)
    inventory = checked(args.inventory, args.inventory_sha256)
    assert raw['complete'] is True
    assert inventory['exit_code'] == 0 and not inventory['collection_errors']
    assert len(inventory['tests']) == inventory['count']
    rows = []
    inputs = [bound(args.summary), bound(args.inventory), bound(__file__)]
    for row in raw['results']:
        file = row['file']
        selected = [test for test in inventory['tests'] if test['file'] == file]
        assert selected, file
        log, junit = row['log'], row['junit']
        assert bound(log['path']) == log and bound(junit['path']) == junit
        command_path = Path(log['path']).parent / 'command.json'
        command = json.loads(command_path.read_text())
        assert command['argv'] == row['argv'], command_path
        assert command['source_before'] == row['source_before'] == row['source_after']
        assert Path(row['source_before']['path']).resolve() == ROOT / file
        # Reported planning current_source is not execution authority; observed
        # source_before/source_after records bind what actually ran.
        names = set()
        for test in selected:
            suffix = test['nodeid'].split('::', 1)[1]
            head, bracket, parameters = suffix.partition('[')
            pieces = head.split('::')
            names.add((pieces[-1] + bracket + parameters,
                       '.'.join([Path(file).stem, *pieces[:-1]])))
        seen = set()
        for case in ET.parse(junit['path']).getroot().iter('testcase'):
            matches = [key for key in names if case.get('name') == key[0]
                       and (case.get('classname', '') == key[1]
                            or case.get('classname', '').endswith('.' + key[1]))]
            assert len(matches) == 1, (file, case.attrib, matches)
            seen.add(matches[0])
        assert seen == names, (file, 'JUnit does not cover final whole-file inventory')
        rows.append({'file': file, 'selection_kind': 'entire_file_inventory',
                     'selected_nodeids': [file + '::' + test['nodeid'].split('::', 1)[1] for test in selected],
                     'selected_nodes': len(selected), 'command_json': bound(command_path),
                     'log': log['path'], 'log_sha256': log['sha256'],
                     'junit': junit['path'], 'junit_sha256': junit['sha256'],
                     'source_sha256_before': row['source_before']['sha256'],
                     'source_sha256_after': row['source_after']['sha256'],
                     'exit_code': row['exit_code'], 'seconds': row.get('seconds')})
    result = {'schema_version': 1, 'complete': True, 'results': rows,
              'normalization_inputs': inputs,
              'normalization': 'Metadata only: selected_nodeids derived from final inventory; original actual command.json argv unchanged. No tests/apps/imports executed.'}
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(bound(args.output)))


if __name__ == '__main__':
    main()
