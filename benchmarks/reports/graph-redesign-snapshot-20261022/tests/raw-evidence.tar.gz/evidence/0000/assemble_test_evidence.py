"""Join sealed pytest metadata only. Never runs/imports tests, compilers or applications."""
import argparse
from collections import Counter, defaultdict
from hashlib import sha256
import json
from pathlib import Path
import shutil
import xml.etree.ElementTree as ET

ROOT = Path('/home/jirka/research/fortran-abomination')


def digest(path):
    return sha256(Path(path).read_bytes()).hexdigest()


def load_bound(item):
    assert item.get('sha256') and digest(item['path']) == item['sha256'], item
    return json.loads(Path(item['path']).read_text())


def omitted_junit_module_allowed(suite, files, argv):
    if suite not in {'main', 'pipeline'} or len(files) != 1:
        return False
    called_files = {str(Path(arg.split('::', 1)[0]).resolve().relative_to(ROOT)) for arg in argv
                    if not arg.startswith('-') and Path(arg.split('::', 1)[0]).suffix == '.py'}
    return called_files == set(files)


def junit_case_matches(node, case, module_omitted=False):
    if node['test_name'] != case.get('name'):
        return False
    reported = case.get('classname', '')
    expected = node['class_suffix']
    if reported == expected or reported.endswith('.' + expected):
        return True
    # Pytest's external-config runs may omit only the file module prefix:
    # preserve actual XML and require the exact collected class chain (or '').
    return module_omitted and reported == expected[len(Path(node['file']).stem):]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--recipe', type=Path, required=True)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--assemble', action='store_true')
    args = parser.parse_args()
    if not args.assemble:
        print('PENDING: metadata-only recipe; --assemble requires sealed authors and root source authority')
        return
    recipe = json.loads(args.recipe.read_text())
    assert recipe['status'] == 'root_sealed_complete_inputs', 'Still pending'
    assert args.output and not args.output.exists(), 'Fresh archive directory required'
    authority = load_bound(recipe['root_source_authority_addendum'])
    assert authority['shared_test_dependency_audit_complete'] is True
    archive = {}
    def retain(path):
        path = Path(path).resolve()
        archive[str(path)] = digest(path)
    retain(args.recipe)
    retain(Path(__file__))
    retain(recipe['root_source_authority_addendum']['path'])
    def inventory_nodes(entries):
        result = {}
        for inventory in entries:
            data = load_bound(inventory)
            assert data['exit_code'] == 0 and not data['collection_errors']
            assert len(data['tests']) == inventory['expected_count'] == data['count']
            retain(inventory['path'])
            for test in data['tests']:
                key = inventory['suite'] + '::' + test['file'] + '::' + test['nodeid'].split('::', 1)[1]
                assert key not in result, key
                suffix = test['nodeid'].split('::', 1)[1]
                head, bracket, parameters = suffix.partition('[')
                pieces = head.split('::')
                result[key] = {'suite': inventory['suite'], 'file': test['file'], 'suffix': suffix,
                               'test_name': pieces[-1] + bracket + parameters,
                               'class_suffix': '.'.join([Path(test['file']).stem, *pieces[:-1]]),
                               'original_nodeid': test['nodeid']}
        return result
    nodes = inventory_nodes(recipe['inventories'])
    originals = inventory_nodes(recipe['original_inventories'])
    lineages = recipe['retired_node_lineage']
    assert set(originals) - set(nodes) == set(lineages), 'Unexplained removed original nodes'
    for old, replacement in lineages.items():
        assert replacement['replacement'] in nodes and old not in nodes
        evidence = replacement['evidence']
        assert evidence.get('sha256') and digest(evidence['path']) == evidence['sha256']
        retain(evidence['path'])
    assert set(nodes) - set(originals) - {x['replacement'] for x in lineages.values()} == set(recipe['added_nodes'])
    all_nodes, histories = originals | nodes, defaultdict(list)
    runs = []
    # Root seals explicit order: first passes, then reviewed repairs/capability/node-shard follow-ups.
    for entry in recipe['summaries_in_resolution_order']:
        summary = load_bound(entry)
        assert summary['complete'] is True, entry
        retain(entry['path'])
        for evidence in summary.get('normalization_inputs', []):
            assert digest(evidence['path']) == evidence['sha256'], evidence
            retain(evidence['path'])
        for row in summary['results']:
            suite = row.get('suite', entry['suite'])
            assert suite in {'main', 'pipeline'}, ('Missing/unknown run suite', suite)
            command_path = Path(row['log']).parent / 'command.json'
            if row.get('command_json'):
                command_path = Path(row['command_json']['path'])
                assert digest(command_path) == row['command_json']['sha256']
            command = json.loads(command_path.read_text())
            files = row.get('files', [row.get('file')])
            selected = []
            if row.get('selection_kind') == 'entire_file_inventory':
                # Actual argv remains whole-file; node coverage is a separate
                # derivation from the sealed final collection, never fake argv.
                pytest_args = command['argv'][command['argv'].index('pytest') + 1:]
                assert not any('::' in arg for arg in pytest_args)
                assert not any(arg in {'-k', '-m', '--lf', '--last-failed', '--collect-only'}
                               or arg.startswith(('--deselect', '--ignore')) for arg in pytest_args)
                called_files = {str(Path(arg).resolve().relative_to(ROOT)) for arg in pytest_args
                                if not arg.startswith('-') and Path(arg).suffix == '.py'}
                assert called_files == set(files), (command_path, called_files, files)
                selected = [suite + '::' + node for node in row['selected_nodeids']]
                expected = {key for key, node in nodes.items()
                            if node['suite'] == suite and node['file'] in files}
                assert set(selected) == expected, (command_path, 'whole-file inventory mismatch')
            else:
                for arg in command['argv']:
                    if '::' not in arg:
                        continue
                    path, suffix = arg.split('::', 1)
                    key = suite + '::' + str(Path(path).resolve().relative_to(ROOT)) + '::' + suffix
                    assert key in all_nodes and all_nodes[key]['file'] in files, key
                    selected.append(key)
            assert selected and len(set(selected)) == len(selected)
            selected_count = row.get('selected_nodes', row.get('nodes', command.get('nodes')))
            assert isinstance(selected_count, int) and len(selected) == selected_count
            for label in ('log', 'junit'):
                if row.get(label):
                    assert not row.get(label + '_sha256') or digest(row[label]) == row[label + '_sha256']
                    retain(row[label])
            retain(command_path)
            tested_sha = row.get('source_sha256_before', row.get('source_sha256', command.get('source_sha256_before', command.get('source_sha256'))))
            tested_sources = {file: (tested_sha.get(file) if isinstance(tested_sha, dict) else tested_sha)
                              or authority['first_pass_unchanged_files_sha256'].get(file) for file in files}
            after = row.get('source_sha256_after')
            assert not after or all(tested_sources[file] == (after.get(file) if isinstance(after, dict) else after) for file in files)
            cases = defaultdict(list)
            if row.get('junit'):
                module_omitted = omitted_junit_module_allowed(suite, files, command['argv'])
                for case in ET.parse(row['junit']).getroot().iter('testcase'):
                    matches = [key for key in selected
                               if junit_case_matches(all_nodes[key], case, module_omitted)]
                    assert len(matches) == 1, (command_path, case.attrib, matches)
                    errors = [item for item in case if item.tag in ('failure', 'error', 'skipped')]
                    cases[matches[0]].extend([{'outcome': item.tag, 'message': item.get('message'), 'text': item.text} for item in errors]
                                            or [{'outcome': 'passed'}])
            if row.get('selection_kind') == 'entire_file_inventory' and row['exit_code'] == 0:
                assert set(cases) == set(selected), (command_path, 'incomplete whole-file JUnit coverage')
            run_id = len(runs)
            runs.append({'id': run_id, 'summary': entry['path'], 'command': str(command_path), 'files': files,
                         'suite': suite,
                         'actual_argv': command['argv'], 'selection_kind': row.get('selection_kind', 'explicit_node_argv'),
                         'selected_nodes': selected, 'exit_code': row['exit_code'], 'seconds': row.get('seconds'),
                         'tested_source_sha256': tested_sources, 'log': row['log'], 'junit': row.get('junit')})
            for key in selected:
                observed = cases[key] or [{'outcome': 'not_reported', 'process_exit_code': row['exit_code']}]
                histories[key].append({'run': run_id, 'source_sha256': tested_sources[all_nodes[key]['file']], 'observations': observed})
    current = {file: digest(ROOT / file) for file in {node['file'] for node in nodes.values()}}
    final, blocked = {}, []
    approved_skips = recipe['legitimate_final_skips']
    for key, node in nodes.items():
        applicable = [attempt for attempt in histories[key] if attempt['source_sha256'] == current[node['file']]]
        latest = applicable[-1] if applicable else None
        outcomes = {item['outcome'] for item in latest['observations']} if latest else {'missing_current_source_execution'}
        outcome = next((state for state in ('error', 'failure', 'not_reported', 'missing_current_source_execution', 'skipped') if state in outcomes), 'passed')
        if latest and outcome in {'passed', 'skipped'} and runs[latest['run']]['exit_code'] != 0:
            outcome = 'process_failed'
        if outcome == 'skipped':
            approval = approved_skips.get(key)
            assert approval and approval['reason'] and approval['evidence'], ('Unclassified skip', key)
            for evidence in approval['evidence']:
                assert evidence.get('sha256') and digest(evidence['path']) == evidence['sha256']
                retain(evidence['path'])
        elif outcome != 'passed':
            blocked.append(key)
        final[key] = {'outcome': outcome, 'current_source_sha256': current[node['file']], 'latest_current_attempt': latest,
                      'attempts': histories[key], 'skip_classification': approved_skips.get(key)}
    for evidence in recipe['additional_small_evidence']:
        assert digest(evidence['path']) == evidence['sha256']
        retain(evidence['path'])
    args.output.mkdir()
    copied = []
    for index, (source, expected) in enumerate(sorted(archive.items())):
        assert digest(source) == expected
        destination = args.output / 'evidence' / f'{index:04d}' / Path(source).name
        destination.parent.mkdir(parents=True)
        shutil.copyfile(source, destination)
        assert digest(destination) == expected
        copied.append({'original_path': source, 'archive_path': str(destination.relative_to(args.output)), 'sha256': expected})
    retired = {key: {'lineage': value, 'historical_attempts': histories[key],
                     'retired_outcomes_are_not_current_replacement_results': True} for key, value in lineages.items()}
    for name, value in [('nodes.json', final), ('retired-node-history.json', retired), ('runs.json', runs), ('manifest.json', copied)]:
        (args.output / name).write_text(json.dumps(value, indent=2) + '\n')
    counts = dict(Counter(value['outcome'] for value in final.values()))
    result = {'status': 'blocked_incomplete_or_failing_final_nodes' if blocked else 'complete_with_classified_skips' if counts.get('skipped') else 'complete_all_nodes_passed',
              'inventoried_nodes': len(nodes), 'nodes_by_suite': dict(Counter(n['suite'] for n in nodes.values())),
              'original_nodes': len(originals), 'explicit_retired_replacements': len(lineages),
              'explicit_added_nodes': recipe['added_nodes'], 'final_outcomes': counts, 'blocked_nodes': blocked,
              'subtests': 'Coverage counts unique collected nodes matched to testcase elements, not testsuite.tests totals; passed subtests never inflate coverage.',
              'all_required_nodes_accounted_for': not blocked, 'first_failures_skips_timeouts_preserved': True,
              'final_resolution': 'Latest current-test-source attempt per exact node in root-sealed resolution order; classified skips never counted as passed.',
              'source_authority': recipe['root_source_authority_addendum'], 'no_tests_or_applications_executed': True}
    (args.output / 'summary.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result))
    raise SystemExit(1 if blocked else 0)


if __name__ == '__main__':
    main()
