"""Read-only, NUL-safe working/staged manifest audit. Never invokes git add or writes an index."""
import argparse
from collections import Counter
from hashlib import sha256
import json
import os
from pathlib import Path
import stat
import subprocess

ROOT = Path('/home/jirka/research/fortran-abomination')
PARENT_PATHS = ('README.md', 'compiler', 'containers', 'benchmarks/reports/graph-redesign-snapshot-20261022')
COMPANION_PATHS = frozenset(('elmm_pipeline/cli.py', 'elmm_pipeline/local_adapter.py',
    'tests/test_application_build.py', 'tests/test_checked_execution_plan.py', 'tests/test_collective_scopes.py',
    'tests/test_local_scopes.py', 'tests/test_owner_measurement.py', 'tests/test_scope_extraction.py',
    'tests/test_scoped_adaptation.py', 'tests/test_selection_request.py', 'elmm_pipeline/_legacy_scopes.py',
    'elmm_pipeline/dataflow_graph.py', 'tests/test_current_scope_protocol.py', 'tests/test_dataflow_graph.py',
    'elmm_pipeline/gpu_validation.py', 'tests/test_gpu_validation.py'))
COMPANION_BASE = '81e374410efe61d2e6dd64e8968264b22991fac5'
ENV = {**os.environ, 'GIT_OPTIONAL_LOCKS': '0'}

def git(root, *args):
    return subprocess.run(['git', *args], cwd=root, env=ENV, check=True, capture_output=True).stdout

def digest(data):
    return sha256(data).hexdigest()

def path_text(value):
    return value.decode('utf-8', errors='surrogateescape')

def index_record(root):
    path = Path(path_text(git(root, 'rev-parse', '--git-path', 'index')).strip())
    if not path.is_absolute():
        path = root / path
    return {'path': str(path), 'sha256': digest(path.read_bytes()) if path.exists() else None}

def file_record(root, name):
    p = root / name
    try:
        before = p.lstat()
    except FileNotFoundError:
        return {'exists': False, 'mode': None, 'bytes': 0, 'sha256': None}
    if stat.S_ISLNK(before.st_mode):
        contents = os.fsencode(os.readlink(p))
        mode = '120000'
        kind = 'symlink; git blob is link text, target is not followed'
    elif stat.S_ISREG(before.st_mode):
        contents = p.read_bytes()
        mode = '100755' if before.st_mode & 0o111 else '100644'
        kind = 'regular'
    else:
        raise RuntimeError('Unsupported non-regular path: ' + name)
    after = p.lstat()
    if (before.st_mode, before.st_size, before.st_mtime_ns) != (after.st_mode, after.st_size, after.st_mtime_ns):
        raise RuntimeError('File changed during read: ' + name)
    return {'exists': True, 'kind': kind, 'mode': mode, 'filesystem_mode': oct(stat.S_IMODE(before.st_mode)),
            'bytes': len(contents), 'sha256': digest(contents)}

def parse_status(raw):
    records = iter(raw.split(b'\0'))
    result = []
    for item in records:
        if not item:
            continue
        tag = item[:1]
        if tag == b'1':
            fields = item.split(b' ', 8)
            result.append({'record_type': 'tracked', 'xy': path_text(fields[1]), 'path': path_text(fields[8]),
                           'head_mode': path_text(fields[3]), 'index_mode': path_text(fields[4]), 'worktree_mode': path_text(fields[5])})
        elif tag == b'2':
            fields = item.split(b' ', 9)
            result.append({'record_type': 'rename_or_copy', 'xy': path_text(fields[1]), 'path': path_text(fields[9]),
                           'original_path': path_text(next(records)), 'head_mode': path_text(fields[3]),
                           'index_mode': path_text(fields[4]), 'worktree_mode': path_text(fields[5])})
        elif tag == b'?':
            result.append({'record_type': 'new_nonignored', 'xy': '??', 'path': path_text(item[2:])})
        else:
            raise RuntimeError('Unexpected status record (including unresolved merge): ' + path_text(item))
    return result

def inventory_repository(root, paths, expected=None, base=None):
    before = index_record(root)
    head = path_text(git(root, 'rev-parse', 'HEAD')).strip()
    if base is not None and head != base:
        raise RuntimeError('Companion HEAD differs from authorized base: ' + head)
    raw = git(root, 'status', '--porcelain=v2', '-z', '--untracked-files=all', '--', *paths)
    rows = parse_status(raw)
    excluded = []
    kept = []
    for row in rows:
        if row['path'] == 'command-log.jsonl' or row['path'].startswith('elmm-pipeline/'):
            excluded.append(row)
        else:
            row['working'] = file_record(root, row['path'])
            if 'original_path' in row:
                row['original_working'] = file_record(root, row['original_path'])
            kept.append(row)
    if expected is not None and {r['path'] for r in kept} != expected:
        raise RuntimeError('Companion dirty path set differs from exact authorized16: ' + repr(sorted(r['path'] for r in kept)))
    after = index_record(root)
    if before != after:
        raise RuntimeError('Index changed while read-only inventory was running: ' + str(root))
    return {'root': str(root), 'head': head, 'requested_pathspecs': list(paths), 'dirty_files': kept,
            'explicit_exclusions': excluded, 'index_before': before, 'index_after': after,
            'index_unchanged': True, 'count': len(kept), 'bytes': sum(r['working']['bytes'] for r in kept),
            'kinds': dict(Counter(r['record_type'] for r in kept)),
            'large_files_over_8MiB': [r['path'] for r in kept if r['working']['bytes'] > 8*1024*1024]}

def verify_repository(repo):
    root = Path(repo['root'])
    before = index_record(root)
    if path_text(git(root, 'rev-parse', 'HEAD')).strip() != repo['head']:
        raise RuntimeError('HEAD changed since inventory; rerun inventory: ' + str(root))
    indexed = {}
    for record in git(root, 'ls-files', '--stage', '-z').split(b'\0'):
        if not record:
            continue
        meta, name = record.split(b'\t', 1)
        mode, oid, stage = meta.split()
        if stage != b'0':
            raise RuntimeError('Unmerged index entry: ' + path_text(name))
        indexed[path_text(name)] = (path_text(mode), path_text(oid))
    staged = {path_text(p) for p in git(root, 'diff', '--cached', '--name-only', '--no-renames', '-z').split(b'\0') if p}
    expected = {r['path'] for r in repo['dirty_files']}
    expected.update(r['original_path'] for r in repo['dirty_files'] if 'original_path' in r)
    if staged != expected:
        raise RuntimeError('Cached changed path set does not equal manifest; extra/missing: ' + repr((sorted(staged-expected), sorted(expected-staged))))
    rows = []
    for row in repo['dirty_files']:
        name = row['path']
        current = file_record(root, name)
        if current != row['working']:
            raise RuntimeError('Working bytes/mode changed since manifest: ' + name)
        if not current['exists']:
            if name in indexed:
                raise RuntimeError('Deleted working path still has index entry: ' + name)
            rows.append({'path': name, 'deletion_staged': True})
            continue
        if name not in indexed:
            raise RuntimeError('Working file is not staged: ' + name)
        mode, oid = indexed[name]
        payload = git(root, 'cat-file', 'blob', oid)
        if mode != current['mode'] or len(payload) != current['bytes'] or digest(payload) != current['sha256']:
            raise RuntimeError('Cached blob/mode differs from working manifest: ' + name)
        rows.append({'path': name, 'index_mode': mode, 'index_blob_oid': oid, 'bytes': len(payload),
                     'sha256': digest(payload), 'matches_working_manifest': True})
    after = index_record(root)
    if before != after:
        raise RuntimeError('Index changed while read-only verification was running: ' + str(root))
    return {'root': str(root), 'staged_changes': len(staged), 'rows': rows, 'index_unchanged': True}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=('inventory', 'verify-index'))
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--inventory', type=Path)
    args = parser.parse_args()
    if args.output.exists():
        raise RuntimeError('Refusing to overwrite an evidence receipt: ' + str(args.output))
    result = {'schema_version': 1, 'mode': args.mode, 'git_index_writes': False,
              'commands_policy': 'git status/rev-parse/ls-files/diff/cat-file only; GIT_OPTIONAL_LOCKS=0; NUL path records',
              'helper_sha256': digest(Path(__file__).read_bytes())}
    if args.mode == 'inventory':
        result['status'] = 'working-source inventory; rerun after all final metadata/source bytes stabilize'
        result['parent'] = inventory_repository(ROOT, PARENT_PATHS)
        result['companion'] = inventory_repository(ROOT/'elmm-pipeline', (), COMPANION_PATHS, COMPANION_BASE)
        result['excluded_from_parent'] = ['command-log.jsonl', 'ignored generated/caches', 'entire ignored elmm-pipeline repository']
    else:
        if args.inventory is None:
            raise RuntimeError('verify-index requires --inventory')
        original = json.loads(args.inventory.read_text())
        result['inventory'] = {'path': str(args.inventory), 'sha256': digest(args.inventory.read_bytes())}
        result['parent'] = verify_repository(original['parent'])
        result['companion'] = verify_repository(original['companion'])
        result['status'] = 'both cached blob sets/modes exactly match working-source manifest; no commit performed'
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'output': str(args.output), 'sha256': digest(args.output.read_bytes()), 'mode': args.mode,
                      'parent_count': result['parent'].get('count', result['parent'].get('staged_changes')),
                      'companion_count': result['companion'].get('count', result['companion'].get('staged_changes'))}, indent=2))

if __name__ == '__main__':
    main()
