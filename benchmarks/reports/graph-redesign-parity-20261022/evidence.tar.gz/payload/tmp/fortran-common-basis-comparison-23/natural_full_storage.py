"""Held one-attempt natural full-storage phases; no builds or timing samples."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys

ROOT = Path('/tmp/fortran-common-basis-comparison-23')
REPO = Path('/home/jirka/research/fortran-abomination')
PLAN = ROOT / 'natural-full-storage-plan.json'
MODES = ('native', 'native-repeat', 'committed', 'reworked')


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def verify(bindings):
    for path, expected in bindings.items():
        if digest(path) != expected:
            raise RuntimeError('changed natural control input: ' + path)


def plans(path):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError('duplicate FFTW field')
            result[key] = value
        return result

    def invalid(value):
        raise ValueError('nonfinite FFTW evidence: ' + value)

    rows = [json.loads(line, object_pairs_hook=pairs, parse_constant=invalid)
            for line in Path(path).read_text().splitlines() if line.strip()]
    if len(rows) != 4:
        raise ValueError('exactly four FFTW plans required')
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', choices=('channel-simple', 'channel'), required=True)
    parser.add_argument('--mode', choices=MODES, required=True)
    parser.add_argument('--authorization', type=Path)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print('TEXT ONLY: root authorization, passed short gates and exclusive lease required.')
        return
    if args.authorization is None:
        raise ValueError('explicit root authorization required')
    plan, auth = read(PLAN), read(args.authorization)
    if (auth.get('authorized_execution') != 'fresh_common_basis_natural_full_storage_23'
            or auth.get('plan_sha256') != digest(PLAN)):
        raise ValueError('authorization does not bind this exact natural recipe')
    if sorted(os.sched_getaffinity(0)) != plan['cpu_affinity']:
        raise ValueError('exact affinity 0..11 required')
    bindings = {**plan['inputs_sha256'], str(PLAN): digest(PLAN),
                str(args.authorization.resolve()): digest(args.authorization)}
    prepared_path = Path(plan['prepared_builds'])
    if digest(prepared_path) != auth['prepared_builds_sha256'] or auth['prepared_builds_sha256'] != plan['prepared_builds_sha256']:
        raise ValueError('fresh prepared build differs from root authorization')
    bindings[str(prepared_path)] = auth['prepared_builds_sha256']
    bindings.update(read(plan['preparation_state'])['fixed_inputs_sha256'])
    for case, identity in auth['short_gate_reports'].items():
        if case not in ('channel-simple', 'channel') or identity['path'] != plan['short_gate_reports'][case]:
            raise ValueError('unexpected short gate identity')
        bindings[identity['path']] = identity['sha256']
        gate = read(identity['path'])
        if gate['status'] != 'passed' or not gate['correctness_qualified'] or not gate['full_array_halos_validated']:
            raise ValueError('short gate is not fully passed')
    if set(auth['short_gate_reports']) != {'channel-simple', 'channel'}:
        raise ValueError('both short gates are mandatory')
    verify(bindings)
    sys.path[:0] = [str(REPO / 'containers'), str(REPO / 'elmm-pipeline'), plan['transport_root']]
    import reproduce_e2e as runner
    from probe_prepared_e2e import probe_environment
    from capture_transport import separated_command
    from elmm_pipeline.common import command
    from elmm_pipeline.campaigns.halos import compare_fields, fields
    from elmm_pipeline.validation import compare_vtk, read_vtk, validate_log
    from sgs_experiment import (DEFAULT_CONTRACT, compare_outputs, read_outputs,
                               repository_provenance, select_configuration, verify_contract)
    prepared = read(prepared_path)
    originals, _ = verify_contract(plan['application_root'], read(DEFAULT_CONTRACT))
    if (repository_provenance(originals, read(DEFAULT_CONTRACT), command) != prepared['original_application']
            or digest(DEFAULT_CONTRACT) != prepared['contract_sha256']
            or prepared['calibration_profile']['sha256'] != plan['profile_sha256']
            or prepared['field_policy'] != plan['field_policy']):
        raise ValueError('prepared source/profile/policy differs from natural recipe')
    _selected, authority = runner.validate_prepared_builds(prepared, prepared, threads=4, build_args=[])
    bindings.update(authority)
    source, advection = select_configuration(originals, args.case)
    case_dir = Path(plan['output_root']) / args.case
    mode_index = MODES.index(args.mode)
    if mode_index == 0:
        case_dir.mkdir(parents=True, exist_ok=False)
        configuration, _, config_dir = runner.prepare_workloads(source, case_dir, advection=advection, steps=None)
        config_hashes = {str(p.relative_to(config_dir)): digest(p) for p in config_dir.rglob('*') if p.is_file()}
        write(case_dir / 'configuration.json', {'configuration': configuration, 'config_dir': str(config_dir),
              'config_sha256': config_hashes, 'prepared_builds_sha256': digest(prepared_path)})
    else:
        for name in MODES[:mode_index]:
            previous_dir = case_dir / 'runs' / name
            previous = read(previous_dir / 'run.json')
            if (previous.get('process_completed') is not True or previous.get('input_postguard_passed') is not True
                    or previous.get('completed_original_configuration') is not True or 'error' in previous):
                raise ValueError('previous phase did not complete structurally')
            bindings.update({str(previous_dir / name): sha for name, sha in
                             {**previous['field_sha256'], **previous['private_artifacts_sha256']}.items()})
            bindings[str(previous_dir / 'run.json')] = digest(previous_dir / 'run.json')
        config = read(case_dir / 'configuration.json')
        configuration, config_dir, config_hashes = config['configuration'], Path(config['config_dir']), config['config_sha256']
        if config['prepared_builds_sha256'] != digest(prepared_path):
            raise ValueError('phase prepared-build binding changed')
    if configuration['expected_max_steps'] is not None or configuration['overrides']:
        raise ValueError('natural correctness must retain original duration')
    current_source = {str(p.relative_to(source)): digest(p) for p in source.rglob('*') if p.is_file()}
    if current_source != config_hashes:
        raise ValueError('natural source configuration differs from copied original')
    bindings.update({str(config_dir / name): sha for name, sha in config_hashes.items()})
    bindings[str(case_dir / 'configuration.json')] = digest(case_dir / 'configuration.json')
    if args.mode == 'reworked':
        evidence_path = case_dir / 'control-evidence.json'
        evidence = read(evidence_path)
        _reference, _fields, _imported, control_inputs = runner.validate_control_evidence(
            evidence, prepared, case=args.case, configuration=configuration, configuration_dir=config_dir, threads=4)
        bindings.update(control_inputs)
        bindings[str(evidence_path)] = digest(evidence_path)
    verify(bindings)
    directory = case_dir / 'runs' / args.mode
    directory.parent.mkdir(exist_ok=True)
    runner.run_directory(config_dir, directory)
    mode = 'native' if args.mode == 'native-repeat' else args.mode
    built, diagnostic = prepared['builds'][mode], prepared['diagnostic_builds'][mode]
    argv = [diagnostic['binary'], *configuration['runtime_arguments']]
    if argv[1:] != ["output_dir='output/'"]:
        raise ValueError('unexpected target application arguments')
    environment = probe_environment(4)
    environment.pop('CUDA_VISIBLE_DEVICES', None)
    if args.mode.startswith('native'):
        environment['CUDA_VISIBLE_DEVICES'] = ''
    if environment.get('LD_PRELOAD') not in (None, '', plan['controller']):
        raise ValueError('unexpected inherited preload')
    environment.update(LD_PRELOAD=plan['controller'], FORT_FFTW_CONTROL_MODE='verify',
        FORT_FFTW_CONTROL_PREFIX=plan['wisdom_prefix'], FORT_FFTW_CONTROL_LOG=str(directory / 'fftw-plans.jsonl'))
    row = {'mode': args.mode, 'argv': argv, 'cwd': str(directory), 'binary_sha256': diagnostic['sha256'],
        'production_binary_sha256': built['sha256'], 'build_receipt_sha256': built['build_receipt_sha256'],
        'natural_duration': True, 'completed_original_configuration': False,
        'process_completed': False, 'input_postguard_passed': False, 'performance_sample': False,
        'environment': {key: environment.get(key) for key in plan['environment_record_keys']},
        'full_environment_sha256': hashlib.sha256(json.dumps(environment, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
        'cpu_affinity': sorted(os.sched_getaffinity(0)), 'timeout_seconds': plan['application_timeout_seconds']}
    write(directory / 'run.json', row)
    try:
        verify(bindings)
        log, elapsed = separated_command(argv, cwd=directory, env=environment, log=directory / 'run.log',
                                         timeout=plan['application_timeout_seconds'])
        row.update(process_completed=True, diagnostic_elapsed_seconds=elapsed)
        if plans(directory / 'fftw-plans.jsonl') != plans(plan['expected_plans']):
            raise ValueError('fixed FFTW four-plan attestation differs')
        timing = validate_log(log, None, expected_completed_steps=plan['cases'][args.case]['completed_steps'])
        if not timing['natural_end'] or 'FORT_SCOPED ' in log or 'FORT_OFFLOAD ' in log:
            raise ValueError('natural completion or untraced execution contract failed')
        observed = fields(directory, {**runner.FIELD_POLICY, 'field_count': 20})
        reference_dir = case_dir / 'runs' / 'native'
        reference = fields(reference_dir, {**runner.FIELD_POLICY, 'field_count': 20})
        comparison = compare_fields(observed, reference, runner.FIELD_POLICY)
        vtk = compare_outputs(read_outputs(reference_dir / 'output', read_vtk),
                              read_outputs(directory / 'output', read_vtk), compare_vtk)
        row.update(timing=timing, fields=comparison, vtk=vtk, field_count=20,
            field_sha256={str(p.relative_to(directory)): digest(p) for p in directory.glob('fields-*')},
            completed_original_configuration=True, exact_four_plans=True,
            passed=all(item['passed'] for item in comparison.values()) and vtk['passed'])
    except BaseException as error:
        row['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        try:
            verify(bindings)
            current_originals, _ = verify_contract(plan['application_root'], read(DEFAULT_CONTRACT))
            if repository_provenance(current_originals, read(DEFAULT_CONTRACT), command) != prepared['original_application']:
                raise ValueError('approved original application changed during natural phase')
            runner.validate_prepared_builds(prepared, prepared, threads=4, build_args=[])
            row['input_postguard_passed'] = True
        except BaseException as error:
            row['input_postguard_error'] = {'type': type(error).__name__, 'message': str(error)}
            raise
        finally:
            row['private_artifacts_sha256'] = {str(p.relative_to(directory)): digest(p) for p in directory.rglob('*')
                if p.is_file() and p.name != 'run.json' and not p.name.startswith('fields-')}
            write(directory / 'run.json', row)
    if args.mode == 'committed':
        controls = {name: read(case_dir / 'runs' / name / 'run.json') for name in MODES[:3]}
        source_report = {'schema_version': 1, 'cases': {args.case: {'config_sha256': config_hashes, 'runs': controls}}}
        report_path = case_dir / 'controls-source-report.json'
        if report_path.exists():
            raise FileExistsError('preserve sealed natural source report')
        write(report_path, source_report)
        selected = {'config_dir': str(config_dir), 'config_sha256': config_hashes, 'runs': {}}
        for name, control_row in controls.items():
            run = case_dir / 'runs' / name
            artifacts = list(run.glob('fields-*')) + list((run / 'output').glob('*.vtk')) + [run / 'run.log', run / 'run.json']
            selected['runs'][name] = {'directory': str(run), 'run': control_row,
                'artifacts_sha256': {str(p.relative_to(run)): digest(p) for p in artifacts}}
        evidence = {'schema_version': 1, 'kind': 'fresh-session-natural-controls', 'field_policy': runner.FIELD_POLICY,
            'threads': 4, 'original_application': prepared['original_application'], 'contract_sha256': prepared['contract_sha256'],
            'source_report': {'path': str(report_path), 'sha256': digest(report_path)}, 'cases': {args.case: selected}}
        runner.validate_control_evidence(evidence, prepared, case=args.case, configuration=configuration,
                                         configuration_dir=config_dir, threads=4)
        write(case_dir / 'control-evidence.json', evidence)
    if args.mode == 'reworked':
        evidence_path = case_dir / 'control-evidence.json'
        runner.validate_control_evidence(read(evidence_path), prepared, case=args.case, configuration=configuration,
                                         configuration_dir=config_dir, threads=4)
        rows = [read(case_dir / 'runs' / name / 'run.json') for name in MODES]
        write(case_dir / 'summary.json', {'schema_version': 1, 'status': 'passed' if all(r['passed'] for r in rows) else 'numerical_failed',
            'performance_sample': False, 'all20_shapes_bounds_halos_vtk_passed': all(r['passed'] for r in rows),
            'control_evidence': {'path': str(evidence_path), 'sha256': digest(evidence_path)},
            'runs': [{'mode': r['mode'], 'path': str(case_dir / 'runs' / r['mode'] / 'run.json'),
                      'sha256': digest(case_dir / 'runs' / r['mode'] / 'run.json'), 'passed': r['passed']} for r in rows]})
    print(args.case, args.mode, 'PASS' if row['passed'] else 'STRICT_NUMERICAL_FAIL', flush=True)
    if args.mode == 'reworked' and not all(r['passed'] for r in rows):
        raise SystemExit(2)


if __name__ == '__main__':
    main()
