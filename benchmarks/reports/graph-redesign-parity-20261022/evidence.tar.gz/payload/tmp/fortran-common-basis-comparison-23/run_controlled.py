"""Private FFTW/stream transport around the unchanged public comparison validators."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import sys

REPO = Path('/home/jirka/research/fortran-abomination')
TRANSPORT = Path('/tmp/fortran-separated-diagnostics-18')
CONTROL = Path('/tmp/fortran-fftw-wisdom-diagnostic-01/fftw_control.so')
CONTROL_SOURCE = CONTROL.with_suffix('.c')
WISDOM = Path('/tmp/fortran-fftw-wisdom-diagnostic-01/executed-native-control-01/wisdom.f64.fftw')
EXPECTED = Path('/tmp/fortran-fftw-wisdom-diagnostic-01/executed-native-control-01/native-verify-1/run/plans.jsonl')
sys.path[:0] = [str(REPO / 'containers'), str(REPO / 'elmm-pipeline'), str(TRANSPORT)]
import reproduce_e2e as runner
from capture_transport import separated_command, separated_profile
from elmm_pipeline import common, gpu_profiling

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def pairs(items):
    result = {}
    for name, value in items:
        if name in result:
            raise ValueError('duplicate FFTW evidence field')
        result[name] = value
    return result

def plans(path):
    def invalid(value):
        raise ValueError('nonfinite FFTW evidence')
    rows = [json.loads(line, object_pairs_hook=pairs, parse_constant=invalid)
            for line in Path(path).read_text().splitlines() if line.strip()]
    if len(rows) != 4:
        raise ValueError('exact four FFTW plan attestations required')
    return rows

parser = argparse.ArgumentParser(add_help=False)
parser.add_argument('--prepared-builds', type=Path, required=True)
parser.add_argument('--output-dir', '--output', dest='output', type=Path, required=True)
args, _rest = parser.parse_known_args()
if args.output.exists():
    raise FileExistsError('preserve prior controlled comparison outputs')
prepared = json.loads(args.prepared_builds.read_text())
binaries = {str(Path(row['binary']).resolve()): row['sha256']
            for key in ('builds', 'diagnostic_builds') for row in prepared[key].values()}
expected = plans(EXPECTED)
protected = {str(path): digest(path) for path in (Path(__file__), args.prepared_builds, CONTROL, CONTROL_SOURCE,
                                                WISDOM, EXPECTED, TRANSPORT / 'capture_transport.py',
                                                TRANSPORT / 'target-streams', TRANSPORT / 'target-streams.c',
                                                TRANSPORT / 'native-helper-build.json')}
original_command, original_profile = common.command, gpu_profiling.profile_command
attempts = []

def target(argv):
    return str(Path(str(argv[0])).resolve()) if argv else None

def environment(argv, env, cwd):
    for path, sha in protected.items():
        if digest(path) != sha:
            raise RuntimeError('controlled comparison input changed: ' + path)
    if list(map(str, argv[1:])) != ["output_dir='output/'"]:
        raise ValueError('application arguments differ from the authenticated primary workload argv')
    if digest(target(argv)) != binaries[target(argv)]:
        raise RuntimeError('authenticated application binary changed')
    result = dict(env)
    if result.get('LD_PRELOAD') not in (None, '', str(CONTROL)):
        raise ValueError('unexpected inherited preload in controlled comparison')
    log = Path(cwd) / 'fftw-plans.jsonl'
    if log.exists():
        raise FileExistsError('refuse reuse of FFTW plan evidence')
    result.update(LD_PRELOAD=str(CONTROL), FORT_FFTW_CONTROL_MODE='verify',
                  FORT_FFTW_CONTROL_PREFIX=str(WISDOM).removesuffix('.f64.fftw'),
                  FORT_FFTW_CONTROL_LOG=str(log))
    row = {'argv': list(map(str, argv)), 'cwd': str(cwd), 'binary_sha256': binaries[target(argv)],
           'full_environment_sha256': hashlib.sha256(json.dumps(result, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
           'selected_environment': {key: value for key, value in result.items()
                                    if key.startswith(('FORT_', 'OMP_', 'GOMP_')) or key in
                                    ('LD_PRELOAD', 'LD_LIBRARY_PATH', 'CUDA_VISIBLE_DEVICES', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS')},
           'plan_log': str(log), 'process_completed': False, 'exact_four_plans': False}
    attempts.append(row)
    return result, row

def finish(row):
    for path, sha in protected.items():
        if digest(path) != sha:
            raise RuntimeError('controlled comparison input changed after application: ' + path)
    row['private_inputs_after_unchanged'] = True
    log = Path(row['plan_log'])
    row['plan_log_sha256'] = digest(log)
    actual = plans(log)
    if actual != expected:
        raise RuntimeError('FFTW plan identity/configuration changed from fixed four-plan reference')
    row.update(process_completed=True, exact_four_plans=True)

def command(argv, **options):
    if target(argv) not in binaries:
        return original_command(argv, **options)
    env, row = environment(argv, options['env'], options['cwd'])
    options = {**options, 'env': env}
    try:
        function = (separated_command if options.get('log') is not None
                    and not Path(options['cwd']).name.startswith('round-') else original_command)
        result = function(argv, **options)
        finish(row)
        return result
    except BaseException as error:
        row['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise

def profile(argv, directory, env, cwd, timeout, *, nsys=None):
    if target(argv) not in binaries:
        raise RuntimeError('profiler target is not an authenticated application')
    controlled, row = environment(argv, env, cwd)
    try:
        result = separated_profile(original_profile, argv, directory, controlled, cwd, timeout, nsys=nsys)
        # Public caller retains independent actual CUPTI/profiler/application checks.
        finish(row)
        return result
    except BaseException as error:
        row['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise

common.command, gpu_profiling.profile_command = command, profile
try:
    runner.main()
finally:
    changes = {path: (digest(path) if Path(path).is_file() else None)
               for path, sha in protected.items() if not Path(path).is_file() or digest(path) != sha}
    if args.output.is_dir():
        write(args.output / 'controlled-transport.json', {
            'schema_version': 1, 'kind': 'private fixed-FFTW environment and separate diagnostic stream transport',
            'source_proof_or_numerical_tolerances_changed': False, 'public_command_timer_unchanged': True,
            'controller_applies_same_four_plans_all_modes': True, 'all_environment_values_archived': False,
            'protected_inputs_sha256': protected, 'private_final_postguard_passed': not changes,
            'private_final_postguard_changes': changes, 'applications': attempts,
            'qualifications': ['Fresh common-basis prepared binaries only; no historical private pressure-link retagging.',
                               'Wall times include startup/solver/controller plan verification and logging; this controlled campaign is separate from uncontrolled histories.',
                               'Complete stdout then complete stderr merge is diagnostic transport only; no cross-stream chronology claim.',
                               'No controller capture/relearning, profile editing, rate retuning or execution-policy override.']})

    if changes:
        raise RuntimeError('controlled comparison private final postguard failed')
