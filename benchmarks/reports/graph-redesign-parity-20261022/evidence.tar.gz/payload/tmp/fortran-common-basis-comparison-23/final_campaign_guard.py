"""Private final-campaign guard; sealing reads evidence, execution requires root authorization."""
from pathlib import Path
import argparse
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/tmp/fortran-common-basis-comparison-23')
PLAN = ROOT / 'final-campaign-plan.json'
BINDING = ROOT / 'final-campaign-natural-binding.json'
MODES = ('native', 'native-repeat', 'committed', 'reworked')


def read(path):
    return json.loads(Path(path).read_text())


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write_new(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def verify(bindings):
    for path, expected in bindings.items():
        if sha(path) != expected:
            raise ValueError('protected campaign evidence changed: ' + path)


def seal(plan):
    bindings = dict(plan['inputs_sha256'])
    bindings.update(read(plan['preparation_state'])['fixed_inputs_sha256'])
    bindings.update({str(PLAN): sha(PLAN), str(Path(__file__).resolve()): sha(__file__)})
    for case in plan['cases']:
        directory = ROOT / 'natural-full-storage-01' / case
        summary = read(directory / 'summary.json')
        if (summary['status'] != 'passed' or not summary['all20_shapes_bounds_halos_vtk_passed']
                or summary['performance_sample'] is not False
                or [row['mode'] for row in summary['runs']] != list(MODES)):
            raise ValueError('all four fresh natural diagnostic phases must pass: ' + case)
        for name in ('summary.json', 'configuration.json', 'controls-source-report.json', 'control-evidence.json'):
            bindings[str(directory / name)] = sha(directory / name)
        control = read(directory / 'control-evidence.json')
        if (summary['control_evidence'] != {'path': str(directory / 'control-evidence.json'),
                                          'sha256': sha(directory / 'control-evidence.json')}
                or control['source_report'] != {'path': str(directory / 'controls-source-report.json'),
                                                'sha256': sha(directory / 'controls-source-report.json')}):
            raise ValueError('natural summary/control-source bindings differ')
        configuration = read(directory / 'configuration.json')
        for name, expected in configuration['config_sha256'].items():
            bindings[str(Path(configuration['config_dir']) / name)] = expected
        for item in summary['runs']:
            path = directory / 'runs' / item['mode'] / 'run.json'
            row = read(path)
            if (item['path'] != str(path) or item['sha256'] != sha(path) or item['passed'] is not True
                    or row['mode'] != item['mode'] or row['field_count'] != 20 or row['passed'] is not True
                    or row['performance_sample'] is not False or row['exact_four_plans'] is not True
                    or any(row.get(key) is not True for key in ('natural_duration', 'completed_original_configuration',
                                                               'process_completed', 'input_postguard_passed'))
                    or 'error' in row or 'input_postguard_error' in row):
                raise ValueError('incomplete natural run: ' + str(path))
            if row['timing']['completed_steps'] != plan['cases'][case]['correctness_steps']:
                raise ValueError('natural duration differs')
            bindings[str(path)] = item['sha256']
            if 'fftw-plans.jsonl' not in row['private_artifacts_sha256']:
                raise ValueError('private FFTW evidence is missing')
            for name, expected in {**row['field_sha256'], **row['private_artifacts_sha256']}.items():
                artifact = path.parent / name
                if artifact.resolve().parent != path.parent.resolve() and not artifact.resolve().is_relative_to(path.parent.resolve()):
                    raise ValueError('natural artifact escapes its run')
                if str(artifact) in bindings and bindings[str(artifact)] != expected:
                    raise ValueError('conflicting artifact identities')
                bindings[str(artifact)] = expected
    verify(bindings)
    write_new(BINDING, {'schema_version': 1, 'kind': 'complete fresh-natural private/public artifact closure',
                       'plan_sha256': sha(PLAN), 'guard_sha256': sha(__file__), 'inputs_sha256': bindings,
                       'includes_all_eight_run_json_and_private_artifacts': True,
                       'timing_samples_reused': 0, 'execution_authorized': False})
    print(str(BINDING), sha(BINDING), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--seal', action='store_true')
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--case', choices=('channel-simple', 'channel'))
    parser.add_argument('--authorization', type=Path)
    args = parser.parse_args()
    plan = read(PLAN)
    if args.seal:
        if args.execute:
            raise ValueError('sealing and execution are separate phases')
        seal(plan)
        return
    if not args.execute:
        print('TEXT ONLY: complete natural controls, sealed bindings and root quiet authorization required.')
        return
    if args.case is None or args.authorization is None:
        raise ValueError('case and explicit root authorization required')
    auth, binding = read(args.authorization), read(BINDING)
    if (auth.get('authorized_execution') != 'final_common_basis_seven_round_campaign_23'
            or auth.get('plan_sha256') != sha(PLAN) or auth.get('guard_sha256') != sha(__file__)
            or auth.get('natural_binding_sha256') != sha(BINDING)
            or binding['plan_sha256'] != sha(PLAN) or binding['guard_sha256'] != sha(__file__)):
        raise ValueError('root authorization does not bind this exact campaign')
    if sorted(os.sched_getaffinity(0)) != plan['cpu_affinity']:
        raise ValueError('exact 0..11 CPU affinity required')
    command = next(row for row in plan['commands'] if row['case'] == args.case)
    output = Path(command['output_dir'])
    if output.exists():
        raise FileExistsError('preserve every prior campaign attempt')
    if args.case == 'channel':
        prior = read(ROOT / 'final-campaign-channel-simple-execution.json')
        if prior.get('status') != 'public_campaign_completed' or prior.get('private_postguard_passed') is not True:
            raise ValueError('simple campaign must close successfully before channel')
    bindings = {**binding['inputs_sha256'], str(BINDING): sha(BINDING),
                str(args.authorization.resolve()): sha(args.authorization)}
    receipt_path = ROOT / ('final-campaign-' + args.case + '-execution.json')
    if receipt_path.exists():
        raise FileExistsError('preserve prior execution receipt')
    verify(bindings)
    receipt = {'schema_version': 1, 'case': args.case, 'plan_sha256': sha(PLAN), 'binding_sha256': sha(BINDING),
               'argv': command['argv'], 'cwd': command['cwd'], 'status': 'started', 'timing_samples_reused': 0}
    write_new(receipt_path, receipt)
    try:
        env = {**os.environ, **command['environment_overlay']}
        with Path(command['raw_stdout']).open('xb') as stdout, Path(command['raw_stderr']).open('xb') as stderr:
            process = subprocess.run(command['argv'], cwd=command['cwd'], env=env, stdout=stdout, stderr=stderr, check=False)
        receipt['process_exit_code'] = process.returncode
        if process.returncode:
            raise RuntimeError('public comparison failed; no retry or next case')
        report = read(output / 'report.json')
        if (report['status'] != 'passed' or report['performance_eligible'] is not True
                or report['protocol']['repetitions'] != 7 or report['protocol']['warmups'] != 1
                or not report['correctness_qualified'] or not report['full_array_halos_validated']
                or report['control_evidence']['candidate_natural_correctness_reused'] is not False
                or report['control_evidence']['timing_samples_imported'] != 0):
            raise ValueError('public correctness/transport prerequisites failed')
        full = [row for row in report['correctness'] if 'float64_storage_validation' in row]
        if len(full) != 4 or any(len(row['float64_storage_validation']['fields']) != 20
                                 or row['float64_storage_validation']['passed'] is not True for row in full):
            raise ValueError('all four natural full-storage comparisons require 20 fields')
        if len(report['runs']) != 24 or any(row['traced'] or row['full_storage'] or not row['passed'] for row in report['runs']):
            raise ValueError('complete untraced production sample set required')
        expected = [(mode, number, number == 0) for number in range(8)
                    for mode in ('native', 'committed', 'reworked')[number % 3:] + ('native', 'committed', 'reworked')[:number % 3]]
        if [(row['mode'], row['round'], row['warmup']) for row in report['runs']] != expected:
            raise ValueError('sample rotation/completeness differs')
        if any(report['cuda_profiles'][mode]['metrics']['available'] is not True for mode in ('committed', 'reworked')):
            raise ValueError('actual separate CUPTI diagnostics required')
        receipt.update(status='public_campaign_completed', report_sha256=sha(output / 'report.json'))
    except BaseException as error:
        receipt.update(status='failed', error={'type': type(error).__name__, 'message': str(error)})
        raise
    finally:
        try:
            verify(bindings)
            receipt['private_postguard_passed'] = True
        except BaseException as error:
            receipt.update(status='failed', private_postguard_passed=False,
                           private_postguard_error={'type': type(error).__name__, 'message': str(error)})
            raise
        finally:
            receipt_path.write_text(json.dumps(receipt, indent=2, allow_nan=False) + '\n')


if __name__ == '__main__':
    main()
