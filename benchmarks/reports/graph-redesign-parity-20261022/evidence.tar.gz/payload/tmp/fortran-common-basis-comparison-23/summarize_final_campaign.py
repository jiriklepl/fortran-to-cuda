"""Metadata-only transparent projection into the existing versioned target evaluator."""
from pathlib import Path
import csv
import hashlib
import json
import statistics
import sys

ROOT = Path('/tmp/fortran-common-basis-comparison-23')
REPO = Path('/home/jirka/research/fortran-abomination')
OUT = ROOT / 'final-campaign-analysis-01'
sys.path.insert(0, str(REPO / 'elmm-pipeline'))
from elmm_pipeline.campaigns.targets import evaluate_target, validate_target


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, value):
    with Path(path).open('x') as stream:
        stream.write(json.dumps(value, indent=2, allow_nan=False) + '\n')


def main():
    OUT.mkdir(exist_ok=False)
    plan = read(ROOT / 'final-campaign-plan.json')
    target = plan['performance_target']
    validate_target(target, {'native', 'committed', 'reworked'}, 'reworked')
    case_results, csv_rows, bindings = {}, [], {}
    for case in plan['cases']:
        directory = ROOT / 'final-campaign-01' / case
        report_path, transport_path = directory / 'report.json', directory / 'controlled-transport.json'
        execution_path = ROOT / ('final-campaign-' + case + '-execution.json')
        report, transport, execution = map(read, (report_path, transport_path, execution_path))
        for path in (report_path, transport_path, execution_path):
            bindings[str(path)] = digest(path)
        if (report['status'] != 'passed' or report['performance_eligible'] is not True
                or not report['correctness_qualified'] or not report['full_array_halos_validated']
                or execution['process_exit_code'] != 0 or execution['status'] != 'public_campaign_completed'
                or execution['private_postguard_passed'] is not True or transport['private_final_postguard_passed'] is not True):
            raise ValueError('failed campaign cannot qualify')
        actual_applications = transport['applications']
        if len(actual_applications) != (29 if case == 'channel-simple' else 30):
            raise ValueError('actual application count differs from predeclared workflow')
        if any(row.get('process_completed') is not True or row.get('exact_four_plans') is not True
               or row.get('private_inputs_after_unchanged') is not True for row in actual_applications):
            raise ValueError('application fixed-FFTW/private guard failed')
        # Rename summary keys only; values and each original report remain unchanged.
        summary = {mode: {'median': row['median_seconds'], 'min': row['minimum_seconds'],
                         'max': row['maximum_seconds'], 'samples': row['samples_seconds'],
                         'repetitions': row['repetitions'], 'ratio_to_native': row['ratio_to_native']}
                   for mode, row in report['summary'].items()}
        # All source rows already passed public VTK and row validation; this is
        # the existing evaluator's validation key, not new execution evidence.
        runs = [{'mode': row['mode'], 'round': row['round'], 'warmup': row['warmup'],
                 'traced': row['traced'], 'wall_seconds': row['wall_seconds'],
                 'validation': {'passed': row['passed'] is True and row['vtk_validation']['passed'] is True}}
                for row in report['runs']]
        expected = [(mode, number, number == 0) for number in range(8)
                    for mode in ('native', 'committed', 'reworked')[number % 3:] + ('native', 'committed', 'reworked')[:number % 3]]
        if [(row['mode'], row['round'], row['warmup']) for row in runs] != expected:
            raise ValueError('complete rotation differs from declared one-warmup/seven-round protocol')
        result = evaluate_target({'candidate_mode': 'reworked'}, {'performance_target': target}, summary, runs)
        complete = (result['comfortable']['paired_rounds_complete'] and result['comfortable']['warmups_complete'])
        modes = {}
        for mode, row in summary.items():
            quartiles = statistics.quantiles(row['samples'], n=4, method='inclusive')
            modes[mode] = {**row, 'q1_seconds': quartiles[0], 'q3_seconds': quartiles[2],
                           'iqr_seconds': quartiles[2] - quartiles[0],
                           'excluded_warmup_seconds': next(r['wall_seconds'] for r in runs if r['mode'] == mode and r['warmup'])}
        paired = []
        for number in range(1, 8):
            rows = {row['mode']: row['wall_seconds'] for row in runs if row['round'] == number}
            ratio = rows['reworked'] / rows['committed']
            paired.append({'round': number, 'seconds': rows, 'candidate_to_be58_ratio': ratio,
                           'candidate_wall_difference_percent': 100 * (ratio - 1),
                           'candidate_le_be58': rows['reworked'] <= rows['committed']})
        projection = {'schema_version': 1, 'kind': 'metadata-only existing evaluator projection',
            'source_report': {'path': str(report_path), 'sha256': digest(report_path)},
            'mapping': {'summary': 'median_seconds/minimum_seconds/maximum_seconds/samples_seconds renamed to median/min/max/samples; all values unchanged',
                        'runs': 'mode/round/warmup/traced/wall_seconds unchanged; validation.passed = original passed AND vtk_validation.passed',
                        'execution_or_numerical_evidence_synthesized': False},
            'state': {'candidate_mode': 'reworked'}, 'case': {'performance_target': target},
            'summary': summary, 'runs': runs}
        write(OUT / (case + '-evaluator-projection.json'), projection)
        write(OUT / (case + '-evaluator-result.json'), result)
        ratio = modes['reworked']['median'] / modes['committed']['median']
        case_results[case] = {'qualified_complete_protocol': complete and result['accepted'],
            'evaluator_result': result, 'median_candidate_to_be58_ratio': ratio,
            'candidate_median_wall_difference_percent': 100 * (ratio - 1),
            'candidate_median_wall_reduction_vs_native_percent': 100 * (1 - modes['reworked']['median'] / modes['native']['median']),
            'same_round_candidate_le_be58': sum(row['candidate_le_be58'] for row in paired),
            'measured_samples_per_mode': 7, 'excluded_warmups_per_mode': 1, 'modes': modes,
            'paired_rounds': paired, 'actual_application_processes': len(actual_applications),
            'fresh_candidate_natural_correctness_reused': report['control_evidence']['candidate_natural_correctness_reused'],
            'full_storage_rows': len([row for row in report['correctness'] if 'float64_storage_validation' in row]),
            'all_four_full_storage_rows_have20_fields': all(len(row['float64_storage_validation']['fields']) == 20 for row in report['correctness'] if 'float64_storage_validation' in row),
            'CUPTI': {mode: {key: report['cuda_profiles'][mode]['metrics'][key]
                            for key in ('available', 'kernel_count', 'h2d_bytes', 'd2h_bytes')}
                      for mode in ('committed', 'reworked')}}
        for row in report['runs']:
            csv_rows.append({'case': case, 'mode': row['mode'], 'round': row['round'], 'warmup': row['warmup'],
                             'wall_seconds': repr(row['wall_seconds']), 'traced': row['traced'],
                             'full_storage': row['full_storage'], 'passed': row['passed'],
                             'completed_steps': row['timing']['completed_steps'],
                             'source_report_sha256': digest(report_path), 'cwd': row['cwd']})
    for name in ('final-campaign-plan.json', 'final_campaign_guard.py', 'root-final-campaign-authorization.json',
                 'root-final-campaign-text-review.json', 'final-campaign-independent-source-peer-review.json',
                 'final-campaign-natural-binding.json', 'final-campaign-natural-seal-receipt.json',
                 'prepared-builds.json', 'state.json', 'short-gates-summary.json', 'preparation-and-short-gates-closure.json',
                 'natural-full-storage-plan.json', 'natural_full_storage.py', 'natural-full-storage-01/closure.json',
                 'natural-execution-01/execution-summary.json'):
        bindings[str(ROOT / name)] = digest(ROOT / name)
    bindings[str(Path(__file__).resolve())] = digest(__file__)
    bindings[str(REPO / 'elmm-pipeline/elmm_pipeline/campaigns/targets.py')] = digest(REPO / 'elmm-pipeline/elmm_pipeline/campaigns/targets.py')
    with (OUT / 'all-timing-rows.csv').open('x', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(csv_rows[0]))
        writer.writeheader()
        writer.writerows(csv_rows)
    conclusion = {'schema_version': 1, 'status': 'completed_single_predeclared_campaign',
        'both_case_complete_median_target_met': all(row['qualified_complete_protocol'] for row in case_results.values()),
        'both_case_comfortable_met': all(row['evaluator_result']['comfortable']['met'] for row in case_results.values()),
        'goal_contract': target, 'cases': case_results,
        'quartile_method': 'statistics.quantiles(n=4, method=inclusive); descriptive only, no confidence/noninferiority criterion',
        'all_timing_rows': 48, 'measured_rows': 42, 'excluded_warmup_rows': 6,
        'actual_final_campaign_application_processes': sum(row['actual_application_processes'] for row in case_results.values()),
        'standalone_natural_prequalification_application_processes': 8,
        'campaign_retries': 0, 'samples_filtered': 0, 'timing_samples_imported': 0,
        'limitations': ['Inclusive median parity is the predeclared criterion; each case wins only4/7 same-round comparisons, and comfortable is false in both.',
                        'The small median gains overlap observed variation; no robust/comfortable or statistical-significance claim.',
                        'The separate historical20percent reduction versus native target is not satisfied by these medians.',
                        'Historical snapshot20/private21/private22/old-driver outcomes remain unchanged and are not relabeled.'],
        'source_prepared_profile_identity': {'application_revision': plan['application_revision'],
            'compiler_snapshot': plan['compiler_snapshot'], 'profile_sha256': plan['profile_sha256'],
            'prepared_sha256': plan['prepared_builds_sha256'], 'runtime_id': '9517e2476a8182d00f52d62574c9573549439091eaca7a3d6ffc343f7590a4aa'},
        'bindings_sha256': bindings,
        'analysis_outputs_sha256': {str(path): digest(path) for path in OUT.iterdir() if path.is_file()}}
    write(OUT / 'closure.json', conclusion)
    print(str(OUT / 'closure.json'), digest(OUT / 'closure.json'), flush=True)
    print(json.dumps({case: {'ratio': row['median_candidate_to_be58_ratio'], 'accepted': row['qualified_complete_protocol'],
                            'comfortable': row['evaluator_result']['comfortable']['met'],
                            'same_round_wins': row['same_round_candidate_le_be58']} for case,row in case_results.items()}), flush=True)


if __name__ == '__main__':
    main()
