#!/usr/bin/env python3
"""Resumable fresh common-basis build preparation; never executes an application."""
from pathlib import Path
import argparse
import os
import shutil
import sys
import time

REPO = Path('/home/jirka/research/fortran-abomination')
ROOT = Path('/tmp/fortran-common-basis-comparison-23')
APP = Path('/tmp/fortran-public-approved-apps-23')
PYTHON = REPO / '.venv/bin/python'
BE58 = 'be58ab809296b97ea39d701828a2621adfc6b3dc'
OPTIONS = {'nvcc': '/usr/local/cuda/bin/nvcc', 'cuda_host_cxx': '/usr/bin/g++-14', 'architecture': '86'}
sys.path[:0] = [str(REPO / 'containers'), str(REPO / 'elmm-pipeline')]
import reproduce_e2e as runner
from sgs_experiment import DEFAULT_CONTRACT, application_paths, contract_path, digest, read, repository_provenance, verify_contract, write
from elmm_pipeline.common import command, digest_tree
from elmm_pipeline.build import build
from elmm_pipeline.local_adapter import apply_scope_sources, transform_scopes
from elmm_pipeline._legacy_scopes import transform_scopes as transform_legacy_scopes
from elmm_pipeline.scope_extraction import export_analysis_sources
from elmm_pipeline.structural import Project

PHASES = ('initialize-controls', 'build-native', 'generate-committed', 'build-committed',
          'freeze-candidate', 'generate-sgs', 'generate-convection', 'build-candidate', 'authenticate')

def record(path):
    return {'path': str(Path(path).resolve()), 'sha256': digest(path)}

def check(state):
    for path, expected in state['fixed_inputs_sha256'].items():
        if digest(path) != expected:
            raise RuntimeError('preparation input changed: ' + path)
    original, _hashes = verify_contract(APP, read(DEFAULT_CONTRACT))
    if repository_provenance(original, read(DEFAULT_CONTRACT), command) != state['original_application']:
        raise RuntimeError('approved original application changed')
    for compiler in state.get('compilers', {}).values():
        if digest_tree(Path(compiler['root']) / 'compiler') != compiler['compiler_tree_sha256']:
            raise RuntimeError('frozen compiler changed')
    if 'calibration_profile' in state:
        profile = state['calibration_profile']
        if digest(profile['path']) != profile['sha256']:
            raise RuntimeError('fresh calibration profile changed')

def generation(state, mode, index, name):
    requests = state['selection_requests'][mode]
    request = requests[index]
    app = ROOT / 'work' / mode / 'application'
    paths, _hashes = verify_contract(app, read(DEFAULT_CONTRACT))
    source = contract_path(paths, request['source'])
    sources = [source, *[contract_path(paths, item) for item in request['source_files']]]
    analysis_dir = ROOT / 'work' / mode / 'analysis' / name
    analysis = export_analysis_sources(Project(app, ['DPREC']), analysis_dir, source_files=sources)
    options = {**OPTIONS, **request['options'], 'host_threads': 4}
    output = ROOT / 'generated' / mode / name
    transform = transform_legacy_scopes if mode == 'committed' else transform_scopes
    metadata = transform(source, Path(state['compilers'][mode]['root']), PYTHON, output,
                         entry=request['entry'], source_files=sources[1:], capture_facts=request['capture_facts'],
                         analysis_sources=analysis, gpu_options=options)
    if metadata['scope_manifest']['scope_count'] < 1 or not metadata['gpu_sources']:
        raise RuntimeError('fresh compiler emitted no device work')
    if mode == 'reworked':
        runtime = metadata['scope_manifest']['runtime']
        profile = state['calibration_profile']
        if runtime['runtime_id'] != profile['scoped_runtime_id'] or runtime['numerical_contract'] != profile['numerical_contract']:
            raise RuntimeError('candidate runtime differs from fresh profile')
    write(output / 'metadata.json', metadata)
    state.setdefault('components', {}).setdefault(mode, {})[name] = record(output / 'metadata.json')
    return {'entry': request['entry'], 'analysis': str(analysis), 'metadata': record(output / 'metadata.json'),
            'scope_count': metadata['scope_manifest']['scope_count'], 'gpu_sources': len(metadata['gpu_sources'])}

def application_build(state, mode):
    app = ROOT / 'work' / mode / 'application'
    paths = application_paths(app)
    metadata, changed = None, []
    if mode != 'native':
        names = ['sgs'] if mode == 'committed' else ['sgs', 'convection']
        packages = []
        for name in names:
            identity = state['components'][mode][name]
            if digest(identity['path']) != identity['sha256']:
                raise RuntimeError('generated component metadata changed')
            packages.append(read(identity['path']))
        destinations = {str(path): path for root in paths.values() for path in root.rglob('*') if path.is_file()}
        if len(packages) == 1:
            metadata = packages[0]
            changed = apply_scope_sources(metadata, destinations)
        else:
            metadata = runner.compose_generated_roots(packages, Path(state['compilers'][mode]['root']), PYTHON,
                                                       ROOT / 'generated/reworked/composed', destinations)
            write(ROOT / 'generated/reworked/composed/metadata.json', metadata)
            changed = [Path(item) for item in metadata['changed_sources']]
        state.setdefault('generation', {})[mode] = {
            **{key: metadata[key] for key in ('command', 'artifact_root', 'scope_manifest', 'gpu_sources')},
            'changed_sources': [str(path) for path in changed],
            'scope_packages': [{key: package[key] for key in ('entry', 'command', 'artifact_root', 'scope_manifest')}
                               for package in packages]}
    binary = build(paths['elmm'], paths['PoisFFT'], ROOT / 'work' / mode / 'build',
                   REPO / 'elmm-pipeline/.cache/envs/build/bin/python', REPO / 'elmm-pipeline/.cache/native/lib',
                   jobs=4, threads=4, extra_args=[], patched_sources=changed,
                   extra_sources=[Path(path) for path in metadata['extra_sources']] if metadata else None,
                   gpu_sources=metadata['gpu_sources'] if metadata else None, gpu_options=OPTIONS if metadata else {})
    state.setdefault('builds', {})[mode] = {'binary': str(binary), 'sha256': digest(binary),
        'build_receipt': str(binary.parent / 'build-receipts.json'), 'build_receipt_sha256': digest(binary.parent / 'build-receipts.json')}
    state.setdefault('diagnostic_builds', {})[mode] = runner.relink_diagnostic(
        binary, paths['elmm'] / 'src/main.f90', ROOT / 'work' / mode / 'diagnostic')
    return {'production': state['builds'][mode], 'fullfield': state['diagnostic_builds'][mode]}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=PHASES, required=True)
    parser.add_argument('--profile', type=Path, help='Required only when freezing final candidate; fresh corrected driver13050 calibration')
    parser.add_argument('--candidate-root', type=Path, default=REPO)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        raise SystemExit('Prepared phases only; root authorization and --execute required')
    os.environ['FC'] = '/usr/bin/gfortran-15'
    phase_path = ROOT / 'phases' / (args.phase + '.json')
    if phase_path.exists():
        raise FileExistsError('Preserve prior phase outcome: ' + str(phase_path))
    phase_path.parent.mkdir(parents=True, exist_ok=True)
    state_path = ROOT / 'state.json'
    state = read(state_path) if state_path.exists() else {}
    result = {'schema_version': 1, 'phase': args.phase, 'status': 'running', 'driver': record(__file__),
              'no_application_or_timing_execution': True, 'outer_phase_cap_seconds': 240, 'compiler_phase_cap_seconds': 240}
    write(phase_path, result)
    started = time.monotonic()
    try:
        if args.phase == 'initialize-controls':
            if state:
                raise RuntimeError('common preparation is already initialized')
            contract = read(DEFAULT_CONTRACT)
            original, _hashes = verify_contract(APP, contract)
            fixed = {str(Path(__file__)): digest(__file__), str(DEFAULT_CONTRACT): digest(DEFAULT_CONTRACT),
                     str(REPO / 'containers/requests/elmm-sgs-convection-auto.json'): digest(REPO / 'containers/requests/elmm-sgs-convection-auto.json')}
            for directory in (REPO / 'containers', REPO / 'elmm-pipeline/elmm_pipeline'):
                for path in directory.rglob('*.py'):
                    if 'tests' not in path.relative_to(directory).parts and '__pycache__' not in path.parts:
                        fixed[str(path)] = digest(path)
            state = {'schema_version': 1, 'kind': 'fresh common approved basis three-mode build preparation',
                'fixed_inputs_sha256': fixed, 'contract_sha256': digest(DEFAULT_CONTRACT),
                'original_application': repository_provenance(original, contract, command),
                'selection_requests': {'committed': runner.selection_requests(contract)},
                'compilers': {'committed': runner.snapshot_compiler(REPO, ROOT / 'compilers/committed', revision=BE58)}}
            for mode in runner.MODES:
                for name, source in original.items():
                    shutil.copytree(source, ROOT / 'work' / mode / 'application' / name,
                        ignore=shutil.ignore_patterns('.git', '__pycache__', '*.pyc', '*.o', '*.mod', '.sconsign*', 'SConstruct.pipeline'))
                verify_contract(ROOT / 'work' / mode / 'application', contract)
            result['result'] = {'approved_app_root': str(APP), 'be58': state['compilers']['committed']}
        else:
            check(state)
            state['fixed_inputs_sha256'].setdefault(str(Path(__file__).resolve()), digest(__file__))
            if args.phase == 'build-native':
                result['result'] = application_build(state, 'native')
            elif args.phase == 'generate-committed':
                result['result'] = generation(state, 'committed', 0, 'sgs')
            elif args.phase == 'build-committed':
                result['result'] = application_build(state, 'committed')
            elif args.phase == 'freeze-candidate':
                if args.profile is None or 'reworked' in state['compilers']:
                    raise ValueError('fresh profile and one new final candidate freeze required')
                requests, profile = runner.candidate_calibration(runner.selection_requests(read(DEFAULT_CONTRACT),
                    read(REPO / 'containers/requests/elmm-sgs-convection-auto.json'), scope_execution='graph'), args.profile, threads=4)
                origin = runner.snapshot_compiler(args.candidate_root, ROOT / 'compilers/reworked')
                state['compiler_origin'] = origin
                state['compilers']['reworked'] = {**origin, 'source_root': origin['root'], 'base_commit': None}
                state['selection_requests']['reworked'], state['calibration_profile'] = requests, profile
                result['result'] = {'compiler_origin': origin, 'profile': profile}
            elif args.phase in ('generate-sgs', 'generate-convection'):
                name = args.phase.removeprefix('generate-')
                # Request order is source-authenticated, not assumed from a historical index.
                requests = state['selection_requests']['reworked']
                target = 'subgrid::sgs_sigma_uniform' if name == 'sgs' else 'dynamics::convection'
                found = [index for index, request in enumerate(requests) if request['entry'].lower() == target]
                if len(found) != 1:
                    raise RuntimeError('candidate roots do not match the reviewed SGS/Convection request')
                result['result'] = generation(state, 'reworked', found[0], name)
            elif args.phase == 'build-candidate':
                result['result'] = application_build(state, 'reworked')
            elif args.phase == 'authenticate':
                prepared = {'schema_version': 1, 'kind': 'prepared-elmm-comparison-builds', 'field_policy': runner.FIELD_POLICY,
                    'threads': 4, 'build_args': [], **{key: state[key] for key in ('contract_sha256', 'original_application',
                    'selection_requests', 'compilers', 'builds', 'diagnostic_builds', 'calibration_profile')},
                    'generation': runner.generation_references(state['generation'])}
                _selected, identities = runner.validate_prepared_builds(prepared, prepared, threads=4, build_args=[])
                write(ROOT / 'prepared-builds.json', prepared)
                result['result'] = {'manifest': record(ROOT / 'prepared-builds.json'), 'authenticated_artifacts': len(identities)}
        if 'generation' in state:
            state['generation'] = runner.generation_references(state['generation'])
        check(state)
        write(state_path, state)
        result.update(status='passed', elapsed_seconds=time.monotonic() - started, state_sha256=digest(state_path))
    except BaseException as error:
        result.update(status='failed', elapsed_seconds=time.monotonic() - started,
                      error={'type': type(error).__name__, 'message': str(error)})
        raise
    finally:
        write(phase_path, result)
    print(args.phase, result['status'], result['elapsed_seconds'], flush=True)

if __name__ == '__main__':
    main()
