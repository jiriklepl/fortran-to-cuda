# Fresh ELMM compiler comparison

Status: **passed**.

All timing samples use fresh production executables and include startup, computation, transfers, solver, output and teardown.
Float64 storage diagnostics and runtime tracing execute separately from timing.

Case: **channel**. Performance duration: **matched 100-step cap**, identical in all modes.
Correctness preserves the original configured duration: **True**.

Prepared executables were authenticated against compiler snapshots and executed build receipts; every production timing sample was collected afresh.

Natural native/committed control evidence was reused from `/tmp/fortran-common-basis-comparison-23/natural-full-storage-01/channel/controls-source-report.json` after authenticating all fields, bounds, VTK bytes, logs, binaries and recorded inputs.
Original strict failures remain unchanged. The candidate's natural-duration correctness run is fresh; no timing sample was imported.

| Mode | Median wall (s) | Range (s) | Speedup vs native | Wall reduction | Speedup vs committed |
|---|---:|---:|---:|---:|---:|
| native | 13.258415 | 13.208260–13.461979 | 1.000× | 0.00% | 0.864× |
| committed | 11.453850 | 11.153878–11.654427 | 1.158× | 13.61% | 1.000× |
| reworked | 11.354034 | 11.253441–11.451940 | 1.168× | 14.36% | 1.009× |

Correctness qualified: **True**.
Repeated performance protocol: **True**.

| Mode | Direct kernel launches | CUDA graph submissions | Upload bytes | Download bytes | Allocations | Waits |
|---|---:|---:|---:|---:|---:|---:|
| committed | 301 | 0 | 4036501504 | 1262485504 | 1204 | 602 |
| reworked | 301 | 0 | 4036501504 | 1262485504 | 1204 | 301 |

Counts above are observed runtime events in a separate trace using the same duration as the timing workload. They are not inferred from procedure counts.
See `report.json`, per-run `run.json`, compiler manifests and fresh build receipts for complete provenance, field errors, bounds, outputs and sample values.

| Mode | Accepted tasks | Queue submissions | Graph submissions | Graph replays | Direct kernels | Peak pending tasks |
|---|---:|---:|---:|---:|---:|---:|
| reworked | 301 | 301 | 0 | 0 | 301 | 1 |

Queue and graph counters are completed runtime measurements. Logical kernels, CUDA graph submissions and replay counts are separate quantities.

| Mode | CUPTI kernels | Kernel activity (s) | H2D bytes | D2H bytes | Copy activity (s) |
|---|---:|---:|---:|---:|---:|
| committed | 301 | 0.579408 | 4036501504 | 1262485504 | 0.605613274 |
| reworked | 301 | 0.579433 | 4036501504 | 1262485504 | 0.62198157 |

CUPTI counts and activity sums come from additional Nsight Systems runs. Overlapping device/API durations are not added to process wall time. CUDA API calls and CPU durations remain separate in `report.json`.

| Compiler | Base commit | Exact committed bytes | Compiler tree SHA-256 |
|---|---|---|---|
| committed | `be58ab809296b97ea39d701828a2621adfc6b3dc` | True | `92397e58d8131c979d0ff6acd48a71ab9222aacec00498af6e4a1ac8aba92314` |
| reworked | `None` | False | `57a3073369769534c1a1d57b1ae6f2ed1bdeff5499a0ea7da6aa5c3389abb401` |
