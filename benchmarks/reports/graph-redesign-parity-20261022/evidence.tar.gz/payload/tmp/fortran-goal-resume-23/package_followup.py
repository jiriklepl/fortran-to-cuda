"""Archive exact reviewed follow-up evidence; never launch or modify applications."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path('/tmp/fortran-common-basis-comparison-23')
DEST = Path('/home/jirka/research/fortran-abomination/benchmarks/reports/graph-redesign-parity-20261022')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def write_new(path, data):
    with path.open('xb') as stream:
        stream.write(data)


def json_bytes(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def main():
    proposal_path = ROOT / 'final-campaign-analysis-01/compact-packaging-proposal.json'
    tests_path = Path('/tmp/fortran-goal-resume-23/targeted-test-artifacts.json')
    assert sha(proposal_path.read_bytes()) == 'd14459ac81bbae7582a5f4a48e5f31d3316913869c6bdf82e3b40c04e1531809'
    assert sha(tests_path.read_bytes()) == 'd364f38c559efd297926ae35604cb789702bfdc30b1d9abceb61d3a8b538d641'
    proposal, tests = load(proposal_path), load(tests_path)
    records = {}

    def add(record):
        path = Path(record['path'])
        data = path.read_bytes()
        if record.get('sha256') is not None:
            assert sha(data) == record['sha256'], str(path)
        if record.get('bytes') is not None:
            assert len(data) == record['bytes'], str(path)
        value = {'path': str(path), 'bytes': len(data), 'sha256': sha(data),
                 'archive_member': 'payload/' + str(path).lstrip('/')}
        if str(path) in records:
            assert records[str(path)] == value
        records[str(path)] = value

    for record in proposal['archive_payloads']:
        add(record)
    for group in tests['groups']:
        for record in group['artifacts']:
            add(record)
    extras = [proposal_path, tests_path,
              ROOT / 'independent-final-campaign-review.json',
              Path('/tmp/fortran-goal-resume-23/current-source-commit-audit-v2.json'),
              Path('/tmp/fortran-goal-resume-23/current-frozen-compiler-code-map.json'),
              Path('/tmp/fortran-goal-resume-23/companion-followup-commit.json'),
              Path('/tmp/fortran-goal-resume-23/companion-followup.diff'),
              Path(__file__).resolve()]
    for path in extras:
        add({'path': str(path)})
    # Preserve the exact three companion postimages independently of its ignored checkout.
    for name in load('/tmp/fortran-goal-resume-23/companion-followup-commit.json')['source_sha256']:
        add({'path': '/home/jirka/research/fortran-abomination/elmm-pipeline/' + name})

    DEST.mkdir(parents=True, exist_ok=True)
    archive_path = DEST / 'evidence.tar.gz'
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as archive:
                for record in sorted(records.values(), key=lambda r: r['archive_member']):
                    data = Path(record['path']).read_bytes()
                    assert len(data) == record['bytes'] and sha(data) == record['sha256']
                    info = tarfile.TarInfo(record['archive_member'])
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    archive.addfile(info, io.BytesIO(data))
    expected = {r['archive_member']: r for r in records.values()}
    seen = set()
    with tarfile.open(archive_path, 'r:gz') as archive:
        for member in archive:
            assert member.isfile() and member.name in expected and member.name not in seen
            data = archive.extractfile(member).read()
            assert len(data) == expected[member.name]['bytes']
            assert sha(data) == expected[member.name]['sha256']
            seen.add(member.name)
    assert seen == set(expected)

    for source, name in [
        (ROOT / 'final-campaign-analysis-01/closure.json', 'performance.json'),
        (ROOT / 'final-campaign-analysis-01/summary.md', 'all-samples.md'),
        (ROOT / 'final-campaign-analysis-01/all-timing-rows.csv', 'all-timing-rows.csv'),
        (ROOT / 'independent-final-campaign-review.json', 'independent-review.json'),
        (tests_path, 'targeted-test-evidence.json'),
        (Path('/tmp/fortran-goal-resume-23/current-source-commit-audit-v2.json'), 'source-test-audit.json'),
        (Path('/tmp/fortran-goal-resume-23/companion-followup-commit.json'), 'companion-commit.json'),
        (Path('/tmp/fortran-goal-resume-23/companion-followup.diff'), 'companion-followup.diff'),
    ]:
        write_new(DEST / name, source.read_bytes())
    write_new(DEST / 'external-evidence-references.json', json_bytes({
        'scope': 'Original omitted fields/shapes/VTK/Nsight payload references from the reviewed packaging proposal; large binaries/generated proofs remain additionally authenticated by archived prepared-build manifests.',
        'archived_payload': False, 'records': proposal['external_payload_references']}))
    manifest = {'schema_version': 1,
                'archive': {'path': archive_path.name, 'bytes': archive_path.stat().st_size,
                            'sha256': sha(archive_path.read_bytes())},
                'payload_count': len(records), 'uncompressed_bytes': sum(r['bytes'] for r in records.values()),
                'all_members_reopened_and_sha256_verified': True,
                'original_payloads_unchanged': True,
                'records': sorted(records.values(), key=lambda r: r['archive_member'])}
    write_new(DEST / 'archive-manifest.json', json_bytes(manifest))
    print(json.dumps({k: v for k, v in manifest.items() if k != 'records'}))


if __name__ == '__main__':
    main()
